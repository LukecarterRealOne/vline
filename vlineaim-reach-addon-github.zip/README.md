# VLine Aim Reach Add-on (Minecraft 26.1.2 / Fabric)

This is a **separate companion mod**, not a merge into the original VLine Aim JAR. The uploaded VLine Aim build was compiled and did not include its source, so the add-on is kept modular.

## What it does

When this add-on is installed on a world/server, it applies native Minecraft attribute modifiers:

- Entity interaction range: **+1.0 block** (normally 3.0 -> 4.0 in survival)
- Block interaction range: **+0.5 block** (normally 4.5 -> 5.0 in survival)

It uses the server's normal attribute and interaction validation. It **does not bypass anti-cheat checks** and is intended for single-player, private servers, or servers where the owner has explicitly enabled the feature.

## Install

1. Build this project using GitHub Actions (see below), or run `gradle build` with Java 25 and Gradle 9.7.1 installed.
2. Download `vlineaim-reach-addon-1.0.0.jar` from the Actions artifact.
3. Put that JAR in the `mods` folder alongside `vlineaim-1.1.0-fast-fix.jar`.
4. Single-player: install both JARs in the client `mods` folder. The integrated server loads the add-on too.
5. Multiplayer: the server owner must install the reach add-on on the server as well. A client-only install does not grant extra server-authorized reach.

## GitHub Actions

The workflow is `.github/workflows/build.yml`. Upload the **contents** of this folder to the root of your repository (not a ZIP file inside the repository). On push or manual run, the workflow compiles the mod and publishes an artifact. The artifact includes the new add-on JAR, plus the provided VLine Aim JAR in a combined ZIP.

## Build versions

- Minecraft: 26.1.2
- Fabric Loader: 0.19.5
- Fabric API: 0.155.3+26.1.2
- Java: 25
- Gradle: 9.7.1

The Java source and workflow are packaged here, but the build has **not** been run in this environment. Review the first GitHub Actions build log for any API/compiler mismatch before using it in-game.
